
export class Note {
    id?: number;
    title: string;
    content: string;

    constructor() {
        this.title = '';
        this.content = '';
    }
}
